package ru.gb.java.ekmu.l1;

public class HW1 {
}
