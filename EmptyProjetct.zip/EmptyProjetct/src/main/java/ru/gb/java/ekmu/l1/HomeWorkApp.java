package ru.gb.java.ekmu.l1;

public class HomeWorkApp {
    public static void main(String[] args) {
        printThreeWords() ;
        checkSumSign() ;
        printColor() ;
        compareNumbers();
    }

    static void printThreeWords() {
        System.out.println("Orange");
        System.out.println("Banana");
        System.out.println("Apple");
        System.out.println() ;
    }

    static void checkSumSign() {
        int a = 5 , b = -1008 ;
        if (a + b >= 0) {
            System.out.println ("Сумма положительная") ;
        }
        else {
            System.out.println("Сумма отрицательная") ;
        }
        System.out.println() ;

    }

    static void printColor() {
        int value = 300 ;
        if (value <= 0) {
            System.out.println("Красныый") ;
        }
        if (value > 0 && value <= 100) {
            System.out.println("Жёлтый") ;
        }
        System.out.println("Зелёный");
        System.out.println() ;
    }

    static void compareNumbers() {
        int a = 8, b = 136 ;
        if (a >= b) {
            System.out.println("a >= b") ;
        }
        System.out.println("a < b") ;
    }
    }

