public class HomeWorkApp {

    public static void main(String[] args) {printThreeWords() ;
    }
     public static void printThreeWords() {
        System.out.println("Orange") ;
        System.out.println("Banana") ;
        System.out.println("Apple") ;
    }
}


